#ifndef __UTILS_H__
#define __UTILS_H__ 1

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#include "structs.h"

void read_at_byte(FILE *data, int byte, void *buffer, size_t size);
void write_at_byte(FILE *data, int byte, const void *buffer, size_t size);
void *allocate_memory(size_t size);
void free_memory(void *ptr);
int ata_read_sector(FILE *data, uint32_t lba, uint8_t *buffer);
int ata_write_sector(FILE *data, uint32_t lba, const uint8_t *buffer);
int get_fat_start_sector(PartitionTable *pt, Fat16BootSector *bs, int idx);
int get_root_dir_start_sector(PartitionTable *pt, Fat16BootSector *bs);

void fat16entry_to_str(Fat16Entry *entry);
void prety_print_name(char name[8], char ext[3]);
void print_file_stat(Fat16Entry *entry, int time, int date);

#endif