#pragma once

#include <string>
#include <cstdint>
#include <functional>
#include <iostream>
#include <utility>
#include <cstring>

using CodePoint = uint32_t;

class UTF8String {};
